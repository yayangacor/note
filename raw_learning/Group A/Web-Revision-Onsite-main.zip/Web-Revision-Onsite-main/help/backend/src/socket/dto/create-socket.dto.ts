export class CreateSocketDto {}
